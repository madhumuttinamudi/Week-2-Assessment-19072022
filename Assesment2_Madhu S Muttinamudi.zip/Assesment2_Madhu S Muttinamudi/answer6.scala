import scala.io.StdIn._
    val favoriteMovie = readLine("What is your favorite movie of all times?")
    println(s"$favoriteMovie is totally awesome!")

